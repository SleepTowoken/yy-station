# 05｜数据库与权限设计文档

## 1. 安全目标

后台必须只有垚总能看。

前台使用者无需登录，可以匿名提交内容，但不能读取后台数据。

安全不是靠隐藏 `/admin`，而是靠：

> Supabase Auth + admin_users 管理员表 + Row Level Security

## 2. 数据分类

### A 类：只存在她手机本地

- 前台暗号通过状态
- 当前 Tab 的本地选择
- 自己的节奏未发送备忘
- 宠物类型
- 宠物名字
- 能量豆数量
- 小窝商店已购买物品
- 今日已获得能量豆来源
- 小火花儿本地状态
- 最近生成过的文案

### B 类：她主动发送后进入后台

- 今日回血状态
- 今日回血备注
- 能量补给请求
- 自己的节奏主动发送内容
- 今日穿搭营业中主动发送反馈
- 小火花儿主动发送状态
- 留言

### C 类：敏感数据

需要二次确认和后台清除能力。

- 地址
- 电话
- 取餐信息
- 穿搭图片
- 私人文字备注

## 3. 数据库表

### 3.1 admin_users

```sql
create table if not exists admin_users (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique not null,
  created_at timestamp with time zone default now()
);
```

### 3.2 mood_logs

```sql
create table if not exists mood_logs (
  id uuid primary key default gen_random_uuid(),
  mood text,
  heal_result text,
  note text,
  read boolean default false,
  created_at timestamp with time zone default now()
);
```

### 3.3 supply_requests

```sql
create table if not exists supply_requests (
  id uuid primary key default gen_random_uuid(),
  drink_name text,
  drink_category text,
  sugar_preference text default '无糖 / 不额外加糖',
  ice_preference text,
  delivery_method text,
  address text,
  phone text,
  contact_note text,
  available_time text,
  user_note text,
  status text default 'pending',
  order_platform text,
  pickup_code text,
  eta text,
  admin_note text,
  sensitive_cleared boolean default false,
  read boolean default false,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);
```

`status` 建议值：

- pending
- arranged
- delivered
- cancelled

### 3.4 rhythm_logs

```sql
create table if not exists rhythm_logs (
  id uuid primary key default gen_random_uuid(),
  current_status text,
  soft_reminder text,
  rest_status text,
  note text,
  read boolean default false,
  created_at timestamp with time zone default now()
);
```

### 3.5 outfit_logs

```sql
create table if not exists outfit_logs (
  id uuid primary key default gen_random_uuid(),
  style text,
  mode text,
  generated_comment text,
  user_note text,
  image_path text,
  reviewed boolean default false,
  read boolean default false,
  created_at timestamp with time zone default now()
);
```

### 3.6 spark_logs

```sql
create table if not exists spark_logs (
  id uuid primary key default gen_random_uuid(),
  fire_status text,
  action_type text,
  generated_text text,
  note text,
  read boolean default false,
  created_at timestamp with time zone default now()
);
```

### 3.7 guest_messages，可选

```sql
create table if not exists guest_messages (
  id uuid primary key default gen_random_uuid(),
  content text not null,
  read boolean default false,
  created_at timestamp with time zone default now()
);
```

## 4. 开启 RLS

```sql
alter table admin_users enable row level security;
alter table mood_logs enable row level security;
alter table supply_requests enable row level security;
alter table rhythm_logs enable row level security;
alter table outfit_logs enable row level security;
alter table spark_logs enable row level security;
alter table guest_messages enable row level security;
```

## 5. 管理员判断函数

建议创建一个函数，简化 RLS：

```sql
create or replace function is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from admin_users
    where admin_users.id = auth.uid()
  );
$$;
```

## 6. RLS 策略

### 6.1 admin_users

管理员可以读取自己的管理员身份。

```sql
create policy "Admins can read admin users"
on admin_users
for select
to authenticated
using (is_admin());
```

admin_users 的插入建议手动在 Supabase Dashboard 完成，不给前端插入权限。

### 6.2 业务表匿名 insert

以下表允许匿名 insert：

- mood_logs
- supply_requests
- rhythm_logs
- outfit_logs
- spark_logs
- guest_messages

示例：

```sql
create policy "Anyone can insert mood logs"
on mood_logs
for insert
to anon
with check (true);
```

其他表同理。

### 6.3 管理员 select/update

示例：

```sql
create policy "Only admins can read mood logs"
on mood_logs
for select
to authenticated
using (is_admin());

create policy "Only admins can update mood logs"
on mood_logs
for update
to authenticated
using (is_admin())
with check (is_admin());
```

其他业务表同理。

## 7. 禁止匿名读取

不要给 anon 创建 select policy。

匿名用户只能 insert，不能 select/update/delete。

## 8. Storage 私有桶

创建 bucket：

```text
outfit-images
```

要求：

- private bucket
- 不公开访问
- 前台只有主动发送时上传
- 后台登录后通过 signed URL 查看

后台生成临时链接：

```ts
supabase.storage
  .from('outfit-images')
  .createSignedUrl(path, 60 * 10)
```

有效期建议 10 分钟。

## 9. 地址和电话保护

能量补给中的地址/电话是敏感数据。

后台必须提供“清除地址/电话”按钮。

清除逻辑：

```sql
update supply_requests
set address = null,
    phone = null,
    contact_note = null,
    sensitive_cleared = true,
    updated_at = now()
where id = :id;
```

## 10. 不收集的数据

项目不得收集：

- IP 地址
- 地理定位
- 设备信息
- 浏览器指纹
- 页面停留时长
- 访问次数
- 每次点击行为
- 在线状态
- 未登录天数

## 11. 前台暗号说明

前台暗号“晚宀”只是轻量私密入口，不是安全边界。

真正安全边界是：

- Supabase Auth
- admin_users
- RLS

## 12. 权限验收

Codex 实现后必须验证：

- anon 可以 insert mood_logs。
- anon 不能 select mood_logs。
- 未登录用户访问 `/admin` 会跳转登录。
- 登录但不在 admin_users 的用户不能读取后台数据。
- admin_users 中的管理员可以 select/update。
- outfit-images 不是 public bucket。
- 非管理员不能生成 signed URL 查看图片。
