# 04｜技术架构文档

## 1. 技术栈

项目采用：

```text
React + Vite + TypeScript
Tailwind CSS
React Router
Supabase Auth
Supabase Postgres + RLS
Supabase Storage private bucket
localStorage
PWA
Netlify / Vercel
```

## 2. 技术选择说明

### 2.1 为什么用 React + Vite

本项目是轻量移动端 PWA，不需要复杂 SSR，也不是 SEO 项目。React + Vite 更轻、更快，适合快速迭代。

### 2.2 为什么不用 Next.js

项目没有 SSR 强需求。使用 Next.js 会增加复杂度。除非后期要大量 serverless function，否则优先 Vite。

### 2.3 为什么用 Supabase

项目需要：

- 管理员登录
- 数据库存储
- RLS 权限控制
- 图片私有存储
- 后台读取数据

Supabase 可以一套完成。

## 3. 部署方式

推荐 Netlify 或 Vercel。

用户之前有 Netlify 使用经验，第一版可优先 Netlify。

环境变量：

```text
VITE_SUPABASE_URL=
VITE_SUPABASE_ANON_KEY=
```

注意：Supabase anon key 可以暴露在前端，安全边界靠 RLS，而不是靠隐藏 anon key。

## 4. 路由结构

```text
/                    前台：垚总远程加油站
/admin               后台登录
/admin/dashboard     今日动态
/admin/mood          今日回血记录
/admin/supply        能量补给请求
/admin/rhythm        自己的节奏记录
/admin/outfits       今日穿搭营业中
/admin/sparks        小火花儿记录
```

前台和后台同项目部署，靠 Supabase Auth + RLS 做权限隔离。

## 5. 项目目录建议

```text
src/
  components/
    AppLayout.tsx
    BottomNav.tsx
    Card.tsx
    Button.tsx
    PillSelector.tsx
    TextArea.tsx
    Toast.tsx
    ConfirmDialog.tsx
    FloatingPet.tsx
    PetPanel.tsx

  pages/
    Home.tsx
    Gate.tsx
    TodayHeal.tsx
    OwnRhythm.tsx
    OutfitToday.tsx
    LittleSpark.tsx

  admin/
    AdminLogin.tsx
    AdminLayout.tsx
    AdminDashboard.tsx
    AdminMood.tsx
    AdminSupply.tsx
    AdminRhythm.tsx
    AdminOutfits.tsx
    AdminSparks.tsx

  constants/
    messages.ts
    drinks.ts
    theme.ts
    pets.ts

  lib/
    supabase.ts
    storage.ts

  hooks/
    useLocalStorage.ts
    useToast.ts
    useAdminAuth.ts
    useDailyEnergy.ts

  services/
    moodService.ts
    supplyService.ts
    rhythmService.ts
    outfitService.ts
    sparkService.ts
    adminService.ts

  types/
    database.ts
    app.ts
```

## 6. 状态管理

第一版不需要 Redux/Zustand。优先使用：

- React useState
- React Context，必要时用于 toast/pet
- localStorage hooks

如后续状态复杂，再考虑 Zustand，但不得擅自新增依赖，必须先问用户。

## 7. localStorage key 规范

```text
station_passed_gate
station_pet_profile
station_energy_beans
station_pet_items
station_daily_energy_sources
station_rhythm_notes
station_spark_status
station_last_tab
station_stage_status
station_generated_text_cache
```

原则：

- 宠物数据本地保存。
- 自己的节奏未发送备忘本地保存。
- 前台暗号通过状态本地保存。
- 默认不保存地址和电话。
- 只有用户主动勾选“下次自动填这个位置”时，才可保存位置提示，但不建议第一版做。

## 8. 服务层设计

前台组件不要直接散落 Supabase insert 逻辑。统一封装到 services：

- `moodService.createMoodLog()`
- `supplyService.createSupplyRequest()`
- `rhythmService.createRhythmLog()`
- `outfitService.createOutfitLog()`
- `sparkService.createSparkLog()`

第一阶段可先实现 mock 或 no-op，第二阶段接 Supabase。

## 9. PWA 要求

需要支持：

- manifest.json
- theme_color
- icons 占位
- iOS Safari 添加到主屏幕
- Android Chrome 添加到主屏幕

PWA 名称建议：

```text
垚总加油站
```

## 10. 表单与校验

前台表单需要：

- 必填项校验
- 友好错误提示
- 提交中 loading
- 成功 toast
- 失败 toast

错误提示不要技术化。

示例：

- 好像没发出去，再试一下？
- 网络好像走神了，等会儿再试试。
- 这里还差一点点内容。
- 图片有点大啦，换一张或者稍后再试试。

## 11. 图片上传

第三阶段实现。

要求：

- 图片上传前二次确认
- 上传前压缩
- Supabase Storage private bucket
- 后台用 signed URL 查看
- 不使用 public bucket

## 12. 后台认证流程

1. 访问 `/admin`
2. 显示登录页
3. Supabase Auth 邮箱密码登录
4. 获取当前 user
5. 查询 `admin_users` 表验证管理员身份
6. 非管理员显示无权限
7. 数据库 RLS 再次限制 select/update

## 13. Codex 开发注意

- 不允许绕过 service 层直接写散逻辑。
- 不允许擅自新增复杂依赖。
- 不允许改变既定 UI 风格。
- 不允许新增追踪功能。
- 不允许把后台权限只写在前端判断里。
- RLS 是必须实现的真正安全边界。
